package com.example.contactmanager.control;

import com.example.contactmanager.ContactManagerApplication;
import com.example.contactmanager.model.Contact;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;

import java.io.IOException;

public class MainWindowController {
    @FXML
    private BorderPane mainPanel;

    @FXML
    private TableView<Contact> tvContactList;

    @FXML
    private TableColumn<Contact, String> tcName;

    @FXML
    private TableColumn<Contact, String> tcEmail;



    private ContactManagerController contactManagerController;

    public MainWindowController() {
        contactManagerController = ContactManagerController.getContactManagerController();
    }

    /**
     * This method is called each time when a fxml file associated with this object/class is loaded
     */
    public void initialize() {
        //the method (initialize) is called several times by diferents fxml file loads
    }

    private void initializeTableView() {
        ObservableList<Contact> observableList;
        observableList = FXCollections.observableArrayList(contactManagerController.getContacts());

        tvContactList.setItems(observableList);
        tcName.setCellValueFactory(new PropertyValueFactory<Contact,String>("name")); //the tableview search for a method called getName
        tcEmail.setCellValueFactory(new PropertyValueFactory<Contact,String>("email")); //the tableview search for a method called getEmail
    }

    @FXML
    public void loadAddContact(ActionEvent event) throws IOException {
        //FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("add-contact.fxml"));
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(ContactManagerApplication.class.getResource("add-contact.fxml"));

        BorderPane addContactPane = (BorderPane) loader.load();
        mainPanel.getChildren().clear();
        mainPanel.setTop(addContactPane);
    }

    @FXML
    public void loadContactList(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("contact-list.fxml"));

        fxmlLoader.setController(this);
        Parent contactListPane = fxmlLoader.load();

        mainPanel.getChildren().clear();
        mainPanel.setCenter(contactListPane);
        initializeTableView();
    }



    @FXML
    public void showAbout(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Contact Manager");
        alert.setHeaderText("Credits");
        alert.setContentText("Juan Reyes\nAlgorithms II");

        alert.showAndWait();
    }
}