package com.example.animationg3.model;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.input.KeyEvent;

import java.util.ArrayList;

public class Avatar {

    public static final String PATH_IDLE="/animations/hero/idle/adventurer-idle-2-0";
    public static final String PATH_RUN="/animations/hero/run/adventurer-run-0";

    // elementos graficos
    private Canvas canvas;
    private GraphicsContext graphicsContext;
    private ArrayList<Image> idles;
    private ArrayList<Image> runs;
    private int frame;

    // elemntos espaciales
    private Position position;
    private State state;

    private boolean rightPressed;

    public Avatar(Canvas canvas){
        this.canvas = canvas;
        this.graphicsContext = this.canvas.getGraphicsContext2D();
        // 0 is idle | 1 is run
        this.state = State.IDLE;
        this.frame = 0;

        this.idles = new ArrayList<>();
        this.runs = new ArrayList<>();

        this.position = new Position(100,100);

        for (int i = 0; i <= 3; i++) {
            Image image = new Image(getClass().getResourceAsStream(PATH_IDLE+i+".png"), 50, 50, false, false);
            this.idles.add(image);
        }

        for (int i = 0; i <=5 ; i++) {
            Image image = new Image(getClass().getResourceAsStream(PATH_RUN+i+".png"));
            this.runs.add(image);
        }
    }

    public void paint(){
        onMove();

        switch(state){
            case IDLE -> {graphicsContext.drawImage(idles.get(frame%3), position.getX(), position.getY());
                frame++;}
            case RUN -> {
                graphicsContext.drawImage(runs.get(frame%5), position.getX(), position.getY());
                frame++;
            }
        }
    }

    public void onKeyPressed(KeyEvent event){
        switch (event.getCode()){
            case RIGHT : {
                state = State.RUN;
                rightPressed = true;
            }
        }
    }

    public void onKeyReleased(KeyEvent event){
        switch (event.getCode()){
            case RIGHT : {
                state = State.IDLE;
                rightPressed = false;
            }
        }
    }

    public void onMove(){
        if (rightPressed){
            position.setX(position.getX() + 10);
        }
    }

}
