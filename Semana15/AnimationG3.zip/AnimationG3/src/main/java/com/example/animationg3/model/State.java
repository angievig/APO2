package com.example.animationg3.model;

public enum State {
    IDLE,
    RUN
}
