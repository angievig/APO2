package com.example.animationg3.model;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;

/**
 * Abstract Class for each character in a game
 */
public abstract class Character {

    /**the canvas where the character will be drawn**/
    protected Canvas canvas;

    /** The graphic context associated to the canvas**/
    protected GraphicsContext graphicsContext;

    /**the initial position of the character in the canvas**/
    protected Position position;

    public Character(Canvas c){
        canvas = c;
        graphicsContext= c.getGraphicsContext2D();
    }
    public void setPosition(Position pos){
        position= pos;
    }
    public Position getPosition(){
        return position;
    }
    public abstract void paint();

}
