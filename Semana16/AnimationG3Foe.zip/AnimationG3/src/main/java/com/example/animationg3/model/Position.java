package com.example.animationg3.model;

import java.security.PublicKey;

public class Position {

    private double x;
    private double y;

    public Position(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

    public void addY(int step){
        y+= step;
    }
    public void addX(int step){
        x+= step;
    }

    public double distance(Position other  ){
       return Math.sqrt(
                Math.pow(this.x - other.getX(), 2) +
                        Math.pow(this.y - other.getY(), 2)
        );
    }

    public void normalize(){
        double normal = Math.sqrt(Math.pow(x, 2) + Math.pow(y, 2));
        if(normal != 0){
            x /= normal;
            y /= normal;
        }
    }

    public void setSpeed(int speed){
        x *= speed;
        y *= speed;
    }
}
