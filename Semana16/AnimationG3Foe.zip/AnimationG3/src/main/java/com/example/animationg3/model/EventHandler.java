package com.example.animationg3.model;

import javafx.scene.input.KeyEvent;

public interface EventHandler {
    public void onKeyReleased(KeyEvent event);
    public void onKeyPressed(KeyEvent event);
}
