package com.example.animationg3.screens;

import com.example.animationg3.model.Avatar;
import com.example.animationg3.model.Foe;
import com.example.animationg3.model.Position;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyEvent;
import javafx.scene.paint.Color;

public class ScreenA {

    private Canvas canvas;
    private GraphicsContext graphicsContext;
    private Avatar avatar;
    private Foe foe;

    public ScreenA(Canvas canvas) {
        this.canvas = canvas;
        this.graphicsContext = this.canvas.getGraphicsContext2D();
        this.avatar = new Avatar(this.canvas);
        foe= new Foe(this.canvas);
        avatar.setPosition(new Position(100,100));
        foe.setPosition(new Position(200,100));
        Thread foeThread = new Thread(foe);
        foeThread.start();

    }

    public void paint() {
        graphicsContext.setFill(Color.BLACK);
        graphicsContext.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());
        avatar.paint();
        foe.paint();

        //to make the foe chases the hero
        double distance = avatar.getPosition().distance( foe.getPosition());
        System.out.println(distance);

        if(distance < 100){
            double posX = avatar.getPosition().getX() - foe.getPosition().getX();
            double posY = avatar.getPosition().getY() - foe.getPosition().getY();

            Position diff = new Position(posX, posY);
            diff.normalize();
            diff.setSpeed(4);

            foe.getPosition().setX(foe.getPosition().getX() + diff.getX());
            foe.getPosition().setY(foe.getPosition().getY() + diff.getY());
        }

        if(distance < 20){
            foe.kill();
        }

        // to stay in the upper boundary
        if(avatar.getPosition().getY() < 20){
            avatar.getPosition().setY(20);
        }

        // to stay in the left boundary
        if(avatar.getPosition().getX() < 20){
            avatar.getPosition().setX(20);
        }

    }

    public void onKeyPressed(KeyEvent event){
        this.avatar.onKeyPressed(event);
    }

    public void onKeyReleased(KeyEvent event){
        this.avatar.onKeyReleased(event);
    }

}
