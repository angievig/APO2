package com.example.animationg3.model;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.input.KeyEvent;

import java.util.ArrayList;

public class Avatar extends Character implements EventHandler{

    public static final String PATH_IDLE="/animations/hero/idle/adventurer-idle-2-0";
    public static final String PATH_RUN="/animations/hero/run/adventurer-run-0";

    // elementos graficos
    private ArrayList<Image> idles;
    private ArrayList<Image> runs;
    private int frame;

    // elemntos espaciales
    private State state;

    private boolean upPressed;
    private boolean downPressed;
    private boolean leftPressed;
    private boolean rightPressed;

    public Avatar(Canvas canvas){
        super(canvas);

        // 0 is idle | 1 is run
        this.state = State.IDLE;
        this.frame = 0;

        this.idles = new ArrayList<>();
        this.runs = new ArrayList<>();


        for (int i = 0; i <= 3; i++) {
            Image image = new Image(getClass().getResourceAsStream(PATH_IDLE+i+".png"), 50, 50, false, false);
            this.idles.add(image);
        }

        for (int i = 0; i <=5 ; i++) {
            Image image = new Image(getClass().getResourceAsStream(PATH_RUN+i+".png"));
            this.runs.add(image);
        }
    }

    public void paint(){
        onMove();

        switch(state){
            case IDLE -> {graphicsContext.drawImage(idles.get(frame%3), position.getX(), position.getY());
                frame++;}
            case RUN -> {
                graphicsContext.drawImage(runs.get(frame%5), position.getX(), position.getY());
                frame++;
            }
        }
    }
    public void onMove(){
        if(upPressed){
            position.setY(position.getY() - 10);
        }
        if (downPressed){
            position.setY(position.getY() + 10);
        }
        if (leftPressed){
            position.setX(position.getX() - 10);
        }
        if (rightPressed){
            position.setX(position.getX() + 10);
        }
    }

    public void onKeyPressed(KeyEvent event){
        switch (event.getCode()){
            case UP -> { state = State.RUN; upPressed = true; }
            case DOWN ->{ state = State.RUN; downPressed = true;}
            case LEFT -> { state = State.RUN;leftPressed = true;}
            case RIGHT -> { state = State.RUN;rightPressed = true;}
        }
    }

    public void onKeyReleased(KeyEvent event){
        switch (event.getCode()){
            case UP -> { state = State.IDLE; upPressed = false; }
            case DOWN ->{ state = State.IDLE; downPressed = false;}
            case LEFT -> { state = State.IDLE;leftPressed = false;}
            case RIGHT -> { state = State.IDLE;rightPressed = false;}
        }
    }

}
