package com.example.animationg3.model;

import javafx.scene.canvas.Canvas;
import javafx.scene.image.Image;

public class Foe extends Character implements Runnable{
    public static final String PATH="/foeImages/";
    public static final int HEIGHT = 100;
    public static final int STEP = 10;

    private Image imageRight ;
    private Image imageLeft;
    private Image imageDead;

    private Boolean rightSide;
    private boolean alive;

    private int side;



    public Foe(Canvas c){
        super(c);
        imageRight= new Image(getClass().getResourceAsStream(PATH+"pacRight.jpg"), 50, 50, false, false);
        imageLeft= new Image(getClass().getResourceAsStream(PATH+"pacLeft.jpeg"), 50, 50, false, false);
        imageDead= new Image(getClass().getResourceAsStream(PATH+"pacDead.jpg"), 50, 50, false, false);
        rightSide= true;
        alive = true;
    }

    @Override
    public void paint() {
        if (alive){
            if (rightSide) {
                graphicsContext.drawImage(imageRight, position.getX(), position.getY());
                rightSide = false;
            } else {
                graphicsContext.drawImage(imageLeft, position.getX(), position.getY());
                rightSide = true;
            }
        }else{
            graphicsContext.drawImage(imageDead, position.getX(), position.getY());
        }

    }
    public void kill(){ alive = false;}

    public void run(){
        while (alive){
            if (Math.abs(side)<=HEIGHT) {
                position.addY(STEP);
                side += STEP;
            } else if (Math.abs(side)<=2*HEIGHT) {
                position.addX(STEP);
                side += STEP;
            } else if (Math.abs(side)<=3*HEIGHT) {
                position.addY(STEP * -1);
                side += STEP;
            }else if (Math.abs(side)<=4*HEIGHT) {
                position.addX(STEP * -1);
                side += STEP;
            }else{
                side=0;
            }

            try {
                Thread.sleep(300);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }

    }

}
